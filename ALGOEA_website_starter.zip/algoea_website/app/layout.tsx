import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "ALGOEA — Automated Trading. Hosted.",
  description: "Manage your MetaTrader 5 Expert Advisors from one platform."
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}