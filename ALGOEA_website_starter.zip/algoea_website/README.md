# ALGOEA Website Starter

Responsive Next.js marketing website for ALGOEA, styled in a dark charcoal / neon green fintech theme.

## Run locally
1. Install Node.js 20.9+.
2. Run `npm install`.
3. Run `npm run dev`.
4. Open http://localhost:3000.

## Current implementation
- Responsive landing page and navigation
- Product feature sections and IRON SCALPING specification
- R300/month pricing presentation
- Login and registration UI placeholders
- Clear disclosures where live integrations are not yet connected

## Production work still required
This starter is a front-end website, not a live EA hosting service. Before accepting customers or real trading credentials, implement and test:
- Supabase/PostgreSQL schema, row-level security and authentication
- Server-side admin role assignment for `katseatang1@gmail.com` (never trust client-side email checks)
- Payment provider checkout and signed webhook verification
- Windows VPS agent with per-customer isolated MT5 terminal processes
- Secure secret storage and encryption for MT5 credentials
- MQL5 implementation, compilation, strategy testing and deployment pipeline for IRON SCALPING
- Authenticated APIs and WebSocket status updates
- Audit logging, backups, rate limiting, monitoring and legal review

Do not represent the preview chart as account performance. No trading data, payment status, MT5 connection or VPS status is fabricated by this starter.
